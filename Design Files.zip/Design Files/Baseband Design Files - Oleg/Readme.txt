Quarter2_UAV - Copy : contains the KiCad design files for
the baseband portion of Team Pi Senior Design Project.

134 Teensy Updated : contains KiCad design files for the 
Teensy or Signal Processing Portion that we did fabricate,
but did not use in the actual testing of the design.